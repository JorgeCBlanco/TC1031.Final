
/**
YT Video: https://youtu.be/CDXTBLsMIG4
Doc: https://drive.google.com/file/d/1SKt_vvE0eWBrJv_LHK9_O2G-D7R-NzZT/view?usp=drive_link
 */
import java.util.List;

public class Main {
    public static void main(String[] args) {

        // Create users
        User alice = new User("Alice");
        User bob = new User("Bob");
        User carl = new User("Carl");

        // Add interests
        alice.addInterest("music");
        alice.addInterest("fitness");

        bob.addInterest("music");
        bob.addInterest("technology");
        bob.addInterest("gaming");

        carl.addInterest("fitness");
        carl.addInterest("cooking");
        carl.addInterest("travel");

        // Add friends
        alice.addFriend(bob);
        alice.addFriend(carl);

        // Create recommendation
        RecommenderSystem rec = new RecommenderSystem();

        // Get recommendations for Alice
        List<String> result = rec.recommend(alice);

        System.out.println("Recommendations for Alice:");
        for (String interest : result) {
            System.out.println("- " + interest);
        }
    }
}
