import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class User {
    String name;
    Set<String> interests;
    List<User> friends;

    public User(String name) {
        this.name = name;
        this.interests = new HashSet<>();
        this.friends = new ArrayList<>();
    }

    // Adds a new interest to the user
    public void addInterest(String interest) {
        interests.add(interest);
    }

    // Adds a friend to the user's friend list
    public void addFriend(User friend) {
        friends.add(friend);
    }
}
