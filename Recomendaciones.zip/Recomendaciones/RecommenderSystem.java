import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class RecommenderSystem {

    private int similarity(User a, User b) {
        int score = 0;
        for (String interest : a.interests) {
            if (b.interests.contains(interest)) {
                score++;
            }
        }
        return score;
    }

    public List<String> recommend(User target) {
        Map<String, Integer> interestScore = new HashMap<>();

        // Check each friend of the target user
        for (User friend : target.friends) {
            int sim = similarity(target, friend);

            // Add friend's interests weighted by similarity
            for (String interest : friend.interests) {
                if (!target.interests.contains(interest)) {
                    interestScore.put(
                            interest,
                            interestScore.getOrDefault(interest, 0) + sim);
                }
            }
        }

        // Sort interests by score
        List<String> recommendations = new ArrayList<>(interestScore.keySet());
        recommendations.sort((a, b) -> interestScore.get(b) - interestScore.get(a));

        return recommendations;
    }
}
